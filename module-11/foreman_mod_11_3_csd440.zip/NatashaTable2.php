<?php
/*
Name: Natasha Foreman
Course: CSD 440 - Server Side Scripting
Date: May 31st, 2026
Assignment: Module 11.3; Redo for Module Assignment 2.2
Purpose: Create an HTML table using nested PHP loops and display
random numbers in each cell.
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Natasha Table2</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }

        table {
            border-collapse: collapse;
            margin: 20px auto;
        }

        td {
            border: 1px solid black;
            padding: 10px;
            width: 60px;
            text-align: center;
        }
    </style>
</head>
<body>

<h1>Random Number Table</h1>

<table>

<?php for ($row = 1; $row <= 5; $row++) { ?>

<tr>

<?php for ($col = 1; $col <= 5; $col++) { ?>

<td><?php echo rand(1, 100); ?></td>

<?php } ?>

</tr>

<?php } ?>

</table>

</body>
</html>